bl_info = {
    "name": "RCSA Drone Show",
    "author": "Warut & Assistant, RCSA",
    "version": (3, 7, 0),
    "blender": (3, 3, 0),
    "location": "View3D > Sidebar > RCSA Tool",
    "description": "All-in-one tools for modeling, coloring, and exporting, plus UI components for drone show design.",
    "category": "Object",
    "tracker_url": "https://www.facebook.com/rcsayoungpilot/?locale=th_TH",
}

__license__ = "GPLv3"

import sys
import bpy
import os
import builtins as __builtin__
from bpy.props import EnumProperty, StringProperty, PointerProperty
from bpy.types import Operator, Panel, Object, Scene
from functools import partial
from pathlib import Path

#############################################################################
# Vendor Path Setup (From ui_rcsa_studio)
#############################################################################
candidates = [
    Path(__file__).parent,
    Path(__file__).parent.parent,
]
for candidate in candidates:
    path = (Path(candidate) / "vendor" / "skybrush").resolve()
    if path.exists():
        sys.path.insert(0, str(path))
        break

#############################################################################
# Imports from Skybrush/SBStudio (From ui_rcsa_studio)
#############################################################################
from sbstudio.i18n.translations import translations_dict
from sbstudio.plugin.lists import (
    SKYBRUSH_UL_lightfxlist,
    SKYBRUSH_UL_scheduleoverridelist,
)
from sbstudio.plugin.menus import GenerateMarkersMenu
from sbstudio.plugin.model import (
    DroneShowAddonFileSpecificSettings,
    DroneShowAddonGlobalSettings,
    DroneShowAddonProperties,
    DroneShowAddonObjectProperties,
    FormationsPanelProperties,
    LEDControlPanelProperties,
    LightEffect,
    LightEffectCollection,
    ColorFunctionProperties,
    SafetyCheckProperties,
    ScheduleOverride,
    StoryboardEntry,
    Storyboard,
    get_formation_order_overlay,
    get_safety_check_overlay,
)
from sbstudio.plugin.operators import (
    AddMarkersFromStaticCSVOperator,
    AddMarkersFromSVGOperator,
    AddMarkersFromZippedCSVOperator,
    AppendFormationToStoryboardOperator,
    ApplyColorsToSelectedDronesOperator,
    CreateFormationOperator,
    CreateNewScheduleOverrideEntryOperator,
    CreateNewStoryboardEntryOperator,
    CreateLightEffectOperator,
    CreateTakeoffGridOperator,
    DACExportOperator,
    DeselectFormationOperator,
    DetachMaterialsFromDroneTemplateOperator,
    DrotekExportOperator,
    DSSPathExportOperator,
    DSSPath3ExportOperator,
    EVSKYExportOperator,
    DuplicateLightEffectOperator,
    FixConstraintOrderingOperator,
    AddMarkersFromQRCodeOperator,
    GetFormationStatisticsOperator,
    LandOperator,
    LitebeeExportOperator,
    MoveLightEffectDownOperator,
    MoveLightEffectUpOperator,
    MoveStoryboardEntryDownOperator,
    MoveStoryboardEntryUpOperator,
    PrepareSceneOperator,
    RecalculateTransitionsOperator,
    RefreshFileFormatsOperator,
    RemoveFormationOperator,
    RemoveLightEffectOperator,
    RemoveScheduleOverrideEntryOperator,
    RemoveStoryboardEntryOperator,
    ReorderFormationMarkersOperator,
    ReturnToHomeOperator,
    SelectFormationOperator,
    SelectStoryboardEntryForCurrentFrameOperator,
    SetServerURLOperator,
    SkybrushExportOperator,
    SkybrushCSVExportOperator,
    SkybrushPDFExportOperator,
    SwapColorsInLEDControlPanelOperator,
    TakeoffOperator,
    UpdateFormationOperator,
    UpdateFrameRangeFromStoryboardOperator,
    UpdateTimeMarkersFromStoryboardOperator,
    UseSelectedVertexGroupForFormationOperator,
)
from sbstudio.plugin.panels import (
    DroneShowAddonObjectPropertiesPanel,
    ExportPanel,
    FormationsPanel,
    StoryboardEditor,
    LEDControlPanel,
    LightEffectsPanel,
    SafetyCheckPanel,
    SwarmPanel,
    TransitionEditorFromCurrentFormation,
    TransitionEditorIntoCurrentFormation,
)
from sbstudio.plugin.plugin_helpers import (
    register_header,
    register_list,
    register_menu,
    register_operator,
    register_translations,
    register_type,
    unregister_header,
    unregister_list,
    unregister_menu,
    unregister_operator,
    unregister_translations,
    unregister_type,
)
from sbstudio.plugin.state import (
    register as register_state,
    unregister as unregister_state,
)
from sbstudio.plugin.tasks import (
    InitializationTask,
    SafetyCheckTask,
    UpdateLightEffectsTask,
)

#############################################################################
# RCSA Tool - Helper Functions & Core Logic
#############################################################################

def console_print(*args, **kwargs):
    for a in bpy.context.screen.areas:
        if a.type == 'CONSOLE':
            c = {'area': a, 'space_data': a.spaces.active, 'region': a.regions[-1], 'window': bpy.context.window, 'screen': bpy.context.screen}
            s = " ".join([str(arg) for arg in args])
            for line in s.split("\n"):
                bpy.ops.console.scrollback_append(c, text=line)

def print(*args, **kwargs):
    console_print(*args, **kwargs)
    __builtin__.print(*args, **kwargs)

def ShowMessageBox(message="", title="Message", icon='INFO'):
    def draw(self, context):
        self.layout.label(text=message)
    bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)

def getFrameMod(blender_frame_rate, ground_frame_rate):
    return int(round(blender_frame_rate / ground_frame_rate))

def get_rgb(color_array):
    r = int(max(0.0, min(1.0, color_array[0])) * 255)
    g = int(max(0.0, min(1.0, color_array[1])) * 255)
    b = int(max(0.0, min(1.0, color_array[2])) * 255)
    return r, g, b

def replace_with_emission(node, node_tree):
    new_node = node_tree.nodes.new('ShaderNodeEmission')
    sock = node.inputs[0]
    color_link = sock.links[0].from_socket if len(sock.links) > 0 else None
    defaults_in = sock.default_value[:]

    connected_socket_out = None
    if len(node.outputs[0].links) > 0:
        connected_socket_out = node.outputs[0].links[0].to_socket

    new_node.location = (node.location.x, node.location.y)
    if color_link is not None:
        node_tree.links.new(new_node.inputs[0], color_link)
    new_node.inputs[0].default_value = defaults_in

    if connected_socket_out:
        node_tree.links.new(connected_socket_out, new_node.outputs[0])

def material_diffuse_to_emission(mat):
    doomed = [node for node in mat.node_tree.nodes if node.type == 'BSDF_PRINCIPLED']
    for node in doomed:
        replace_with_emission(node, mat.node_tree)
        mat.node_tree.nodes.remove(node)


class RCSA_OT_add_planning_sphere(Operator):
    """สร้าง Sphere สำหรับวางแผนสี พร้อม Material Emission"""
    bl_idname = "rcsa.add_planning_sphere"
    bl_label = "Add Drone"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.5)
        obj = context.active_object
        obj.name = "Drone"
        
        mat = bpy.data.materials.new(name="Material_Drone")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        nodes.clear()
        
        node_emit = nodes.new(type='ShaderNodeEmission')
        node_emit.inputs[0].default_value = (1, 1, 1, 1)
        node_emit.name = "Emission"
        
        node_out = nodes.new(type='ShaderNodeOutputMaterial')
        node_out.location = (200, 0)
        mat.node_tree.links.new(node_emit.outputs[0], node_out.inputs[0])
        
        if obj.data.materials:
            obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)
        return {'FINISHED'}


class RCSA_OT_utility_tools(Operator):
    bl_idname = 'rcsa.utility_tools'
    bl_label = 'RCSA Utility'
    bl_options = {'REGISTER', 'UNDO'}
 
    action: EnumProperty(
        items=[
            ('RENAME', 'Rename', 'Rename'),
            ('SET_COLOR', 'Set Color', 'Set Color'),
            ('SET_FRAME', 'Set Frame', 'Set Frame'),
            ('NEW_MATERIAL', 'New Material', 'New Material')
        ]
    )

    def execute(self, context):
        if self.action == 'SET_COLOR':
            self.set_color(context)
        elif self.action == 'SET_FRAME':
            self.set_frame(context)
        elif self.action == 'NEW_MATERIAL':
            self.new_material(context)
        elif self.action == 'RENAME':
            self.rename_objects(context)
        return {'FINISHED'}

    @staticmethod
    def set_color(context):
        obj_active = bpy.context.active_object
        objs = bpy.context.selected_objects
        if not obj_active or not obj_active.active_material: return
        
        emit_node = obj_active.active_material.node_tree.nodes.get("Emission")
        if not emit_node: return
        
        new_color = emit_node.inputs[0].default_value[:]
        for obj in objs:
            if obj.type == 'MESH' and obj != obj_active:
                mat = obj.active_material
                if mat and "Emission" in mat.node_tree.nodes:
                    mat.node_tree.nodes["Emission"].inputs[0].default_value = new_color
                            
    @staticmethod
    def set_frame(context):
        objs = bpy.context.selected_objects
        scene = bpy.context.scene
        for obj in objs:
            if obj.type == 'MESH' and obj.material_slots:
                 mat = obj.material_slots[0].material
                 if mat and "Emission" in mat.node_tree.nodes:
                     mat.node_tree.nodes["Emission"].inputs[0].keyframe_insert(data_path='default_value', frame=scene.frame_current)
        scene.frame_set(scene.frame_current)

    @staticmethod
    def new_material(context):
        theMaterialName = "Material"
        selectedObjects = bpy.context.selected_objects
        bpy.ops.object.material_slot_remove() 
        
        theMaterial = bpy.data.materials.get(theMaterialName) or bpy.data.materials.new(theMaterialName)
        theMaterial.use_nodes = True

        for obj in selectedObjects:
            if obj.data.materials:
                obj.data.materials[0] = theMaterial
            else:
                obj.data.materials.append(theMaterial)
            material_diffuse_to_emission(theMaterial)

    @staticmethod
    def rename_objects(context):
        for i, obj in enumerate(bpy.context.selected_objects):
            obj.name = f"Drone {i + 1}"


class RCSA_OT_export_path_modal(Operator):
    bl_idname = "rcsa.export_path_modal"
    bl_label = "Export APM Paths"

    filepath: StringProperty(name="Export Path", subtype='FILE_PATH')
    _timer = None

    def invoke(self, context, event):
        self.filepath = context.scene.rcsa_folder_prefix
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        self.scene = context.scene
        self.frame_mod = getFrameMod(self.scene.render.fps, 10)
        self.current_frame = self.scene.frame_start

        if 'Drones' not in bpy.data.collections:
            self.report({'ERROR'}, "ไม่พบ Collection ชื่อ 'Drones'")
            return {'CANCELLED'}

        self.drones = [ob for ob in bpy.data.collections['Drones'].objects if ob.type == 'MESH']
        self.data_map = {ob.name: [] for ob in self.drones}
        
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.01, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            self.cleanup(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':
            if ((self.current_frame - 1) % self.frame_mod) == 0:
                dg = context.evaluated_depsgraph_get()
                for ob in self.drones:
                    eval_ob = ob.evaluated_get(dg)
                    pos = eval_ob.matrix_world.to_translation()
                    x, y, z = int(pos.x * 100), int(pos.y * 100), int(pos.z * 100)
                    r, g, b = get_rgb(eval_ob.color) # Default color
                    
                    # Try to get color from Emission Node
                    if eval_ob.active_material and eval_ob.active_material.use_nodes:
                        nodes = eval_ob.active_material.node_tree.nodes
                        emit = nodes.get('Emission')
                        if emit: r, g, b = get_rgb(emit.inputs[0].default_value)

                    self.data_map[ob.name].append([(x, y, z), (r, g, b)])

            self.current_frame += 1
            if self.current_frame > self.scene.frame_end:
                self.save_files()
                self.cleanup(context)
                return {'FINISHED'}
            else:
                self.scene.frame_set(self.current_frame)

        return {'PASS_THROUGH'}

    def save_files(self):
        os.makedirs(self.filepath, exist_ok=True)
        for i, (name, drone_data) in enumerate(self.data_map.items()):
            num_part = ''.join(filter(str.isdigit, name))
            file_id = num_part if num_part else str(i + 1)
            file_path = os.path.join(self.filepath, f"APM-{file_id}.PATH")
            with open(file_path, 'wb') as f:
                for pos_data, col_data in drone_data:
                    for p in pos_data: f.write(p.to_bytes(2, 'little', signed=True))
                    for c in col_data: f.write(c.to_bytes(2, 'little', signed=True))
        ShowMessageBox("Export เสร็จสมบูรณ์!", "Success", 'CHECKMARK')

    def cleanup(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)


class RCSA_PT_main_panel(Panel):
    bl_label = "RCSA Drone Show"
    bl_idname = "RCSA_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "RCSA Tool"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # --- Box 1: Setup ---
        box = layout.box()
        box.label(text="1. Setup & Creation", icon='OBJECT_DATA')
        box.operator('rcsa.add_planning_sphere', icon='MESH_UVSPHERE')
        box.operator('rcsa.utility_tools', icon='SORTALPHA', text='Rename').action = 'RENAME'

        # --- Box 2: Material ---
        box = layout.box()
        box.label(text="2. Material & Color", icon='MATERIAL')
        box.operator('rcsa.utility_tools', icon='MESH_UVSPHERE', text='New Material [ALL]').action = 'NEW_MATERIAL'
        box.operator('object.make_single_user', icon='MESH_CIRCLE', text='New Material [EACH]').object = True
        
        # --- Inject LED Control from Skybrush into this box ---
        box.separator()
        class DummyPanel:
            bl_idname = "LEDControlPanel"
            bl_label = "LED Control"
            def __init__(self, layout):
                self.layout = layout
        try:
            LEDControlPanel.draw(DummyPanel(box), context)
        except Exception as e:
            box.label(text=f"LED Control GUI Error: {e}")
        
        # --- Box 3: Keyframes ---
        box = layout.box()
        box.label(text="3. Keyframe", icon='KEYINGSET')
        box.operator('rcsa.utility_tools', icon='COLORSET_01_VEC', text='Set Color (Active to Selected)').action = 'SET_COLOR'
        box.operator('rcsa.utility_tools', icon='TEMP', text='Set Keyframe (Current)').action = 'SET_FRAME'

        # --- Box 4: Export ---
        box = layout.box()
        box.label(text="4. Export APM Paths", icon='EXPORT')
        box.prop(scene, "rcsa_folder_prefix")
        box.operator('rcsa.export_path_modal', text='Export Path', icon='FILE_FOLDER')


#############################################################################
# Definitions for Registration
#############################################################################

# From RCSATool
rcsa_classes = (
    RCSA_OT_add_planning_sphere,
    RCSA_OT_utility_tools,
    RCSA_OT_export_path_modal,
    RCSA_PT_main_panel,
)

# From ui_rcsa_studio
types = (
    FormationsPanelProperties,
    ColorFunctionProperties,
    LightEffect,
    LightEffectCollection,
    ScheduleOverride,
    StoryboardEntry,
    Storyboard,
    LEDControlPanelProperties,
    SafetyCheckProperties,
    DroneShowAddonFileSpecificSettings,
    DroneShowAddonGlobalSettings,
    DroneShowAddonProperties,
    DroneShowAddonObjectProperties,
)

operators = (
    PrepareSceneOperator,
    CreateFormationOperator,
    SelectFormationOperator,
    DeselectFormationOperator,
    UpdateFormationOperator,
    ReorderFormationMarkersOperator,
    RemoveFormationOperator,
    CreateNewStoryboardEntryOperator,
    AppendFormationToStoryboardOperator,
    MoveStoryboardEntryDownOperator,
    MoveStoryboardEntryUpOperator,
    SelectStoryboardEntryForCurrentFrameOperator,
    RemoveStoryboardEntryOperator,
    CreateNewScheduleOverrideEntryOperator,
    RemoveScheduleOverrideEntryOperator,
    UpdateFrameRangeFromStoryboardOperator,
    UpdateTimeMarkersFromStoryboardOperator,
    CreateLightEffectOperator,
    DuplicateLightEffectOperator,
    MoveLightEffectDownOperator,
    MoveLightEffectUpOperator,
    RemoveLightEffectOperator,
    CreateTakeoffGridOperator,
    DetachMaterialsFromDroneTemplateOperator,
    FixConstraintOrderingOperator,
    RecalculateTransitionsOperator,
    ApplyColorsToSelectedDronesOperator,
    SwapColorsInLEDControlPanelOperator,
    SetServerURLOperator,
    SkybrushExportOperator,
    SkybrushCSVExportOperator,
    SkybrushPDFExportOperator,
    DACExportOperator,
    DrotekExportOperator,
    DSSPathExportOperator,
    DSSPath3ExportOperator,
    EVSKYExportOperator,
    LitebeeExportOperator,
    UseSelectedVertexGroupForFormationOperator,
    GetFormationStatisticsOperator,
    TakeoffOperator,
    LandOperator,
    ReturnToHomeOperator,
    AddMarkersFromStaticCSVOperator,
    AddMarkersFromSVGOperator,
    AddMarkersFromZippedCSVOperator,
    AddMarkersFromQRCodeOperator,
    RefreshFileFormatsOperator,
)

lists = (SKYBRUSH_UL_lightfxlist, SKYBRUSH_UL_scheduleoverridelist)
menus = (GenerateMarkersMenu,)

# -------------------------------------------------------------------------
# UI Panel Wrappers (Fix for Blender 4.0+ bl_parent_id VS bl_category crash)
# -------------------------------------------------------------------------
# แทนที่จะปรับแก้คลาสของ Skybrush โดยตรง เราจะสร้างคลาสจำลอง (Wrapper) 
# ขึ้นมารับหน้าที่วาด UI แทน เพื่อให้ข้อมูลโครงสร้างสะอาดที่สุด

def create_wrapper_panel(base_cls):
    clean_name = base_cls.__name__
    new_idname = "RCSA_PT_" + clean_name
    
    attrs = {
        'bl_idname': new_idname,
        'bl_label': getattr(base_cls, 'bl_label', clean_name),
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': "Safety Check", # ตั้งให้แสดงในแท็บนี้อย่างเดียวแบบอิสระ
    }
    
    if hasattr(base_cls, 'bl_options'):
        attrs['bl_options'] = base_cls.bl_options
        
    def draw(self, context):
        base_cls.draw(self, context)
    attrs['draw'] = draw
    
    if hasattr(base_cls, 'poll'):
        @classmethod
        def poll(cls, context):
            return base_cls.poll(context)
        attrs['poll'] = poll
        
    if hasattr(base_cls, 'draw_header'):
        def draw_header(self, context):
            base_cls.draw_header(self, context)
        attrs['draw_header'] = draw_header
        
    return type("RCSA_Wrap_" + clean_name, (Panel,), attrs)

# เลือกเฉพาะ Panel จาก Skybrush ที่เราต้องการแสดง
skybrush_panels_original = (
    TransitionEditorFromCurrentFormation,
    TransitionEditorIntoCurrentFormation,
    SafetyCheckPanel,
    DroneShowAddonObjectPropertiesPanel,
)

# นำไปผ่านการ Wrapper
skybrush_wrapper_panels = tuple(create_wrapper_panel(p) for p in skybrush_panels_original)

headers = ()
tasks = (InitializationTask(), SafetyCheckTask(), UpdateLightEffectsTask())
overlay_getters = (
    partial(get_safety_check_overlay, create=False),
    get_formation_order_overlay,
)

#############################################################################
# Master Register / Unregister
#############################################################################

def register():
    # --- Register RCSA Tool ---
    for cls in rcsa_classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.rcsa_folder_prefix = StringProperty(name="Folder Name", default="RCSA_DroneShow")

    # --- Register ui_rcsa_studio ---
    register_translations(translations_dict)
    register_state()
    for custom_type in types:
        register_type(custom_type)
    for operator in operators:
        register_operator(operator)
    for list_ in lists:
        register_list(list_)
    for menu in menus:
        register_menu(menu)
        
    # Register Wrapper Panels
    for panel in skybrush_wrapper_panels:
        bpy.utils.register_class(panel)
        
    for header in headers:
        register_header(header)
    for task in tasks:
        task.register()

    Scene.skybrush = PointerProperty(type=DroneShowAddonProperties)
    Object.skybrush = PointerProperty(type=DroneShowAddonObjectProperties)


def unregister():
    # --- Unregister ui_rcsa_studio ---
    for getter in overlay_getters:
        overlay = getter()
        if overlay:
            overlay.enabled = False
    for task in tasks:
        task.unregister()
    for header in reversed(headers):
        unregister_header(header)
        
    # Unregister Wrapper Panels
    for panel in reversed(skybrush_wrapper_panels):
        bpy.utils.unregister_class(panel)
        
    for menu in menus:
        unregister_menu(menu)
    for list_ in lists:
        unregister_list(list_)
    for operator in reversed(operators):
        unregister_operator(operator)
    for custom_type in reversed(types):
        unregister_type(custom_type)
    unregister_state()
    unregister_translations()

    # --- Unregister RCSA Tool ---
    for cls in rcsa_classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.rcsa_folder_prefix


if __name__ == "__main__":
    register()